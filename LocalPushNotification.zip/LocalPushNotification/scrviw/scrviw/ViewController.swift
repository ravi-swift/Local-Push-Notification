//
//  ViewController.swift
//  scrviw
//
//  Created by Rp on 03/01/19.
//  Copyright © 2019 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var width : NSLayoutConstraint!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        width.constant = UIScreen.main.bounds.size.width * 3
    }


}

